﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD_Aplikacija
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        SqlConnection Kon = new SqlConnection(@"Data Source=DESKTOP-HHPNNPS\SQLEXPRESS;Initial Catalog=NekaBaza;Integrated Security=True"); /* MM 2 sp*/

        SqlCommand kom = new SqlCommand();

        SqlDataReader dr;

        int id = 0;

        private void Form1_Load(object sender, EventArgs e)
        {
            txtRadnikID.Enabled = false;
            PuniLV();
        }

        private void PrazniKontrole()
        { 
            txtRadnikID.Clear();
            txtIme.Clear();
            txtPrezime.Clear();
            txtPlata.Clear();
            maskedDatumZap.Clear();
            checkBoxOU.Checked = false;
            dtDatumR.Value = DateTime.Now;
        }
        private void UnosRadnika()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("UnosRadnika", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue("@Ime", SqlDbType.VarChar).Value = txtIme.Text.ToString();
            cmd.Parameters.AddWithValue("@Prezime", SqlDbType.VarChar).Value = txtPrezime.Text.ToString();
            cmd.Parameters.AddWithValue("@DatumR", SqlDbType.Date).Value = dtDatumR.Text.ToString();
            cmd.Parameters.AddWithValue("@DatumZap", SqlDbType.Date).Value = maskedDatumZap.Text.ToString();
            cmd.Parameters.AddWithValue("@Plata", SqlDbType.Date).Value = txtPlata.Text.ToString();
            cmd.Parameters.AddWithValue("@OzenjenUdata", SqlDbType.Bit).Value = checkBoxOU.Checked.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();

        }

        private void IzmenaRadnika()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("IzmenaRadnika", Kon);
            cmd.CommandType = CommandType.StoredProcedure;
            
            cmd.Parameters.AddWithValue("@RadnikID", SqlDbType.VarChar).Value = txtRadnikID.Text.ToString();
            cmd.Parameters.AddWithValue("@Ime", SqlDbType.VarChar).Value = txtIme.Text.ToString();
            cmd.Parameters.AddWithValue("@Prezime", SqlDbType.VarChar).Value = txtPrezime.Text.ToString();
            cmd.Parameters.AddWithValue("@DatumR", SqlDbType.Date).Value = dtDatumR.Text.ToString();
            cmd.Parameters.AddWithValue("@DatumZap", SqlDbType.Date).Value = maskedDatumZap.Text.ToString();
            cmd.Parameters.AddWithValue("@Plata", SqlDbType.Date).Value = txtPlata.Text.ToString();
            cmd.Parameters.AddWithValue("@OzenjenUdata", SqlDbType.Bit).Value = checkBoxOU.Checked.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();

        }

        private void BrisiRadnika()
        {
            Kon.Open();
            SqlCommand cmd = new SqlCommand("BrisiRadnika", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@RadnikID", SqlDbType.VarChar).Value = txtRadnikID.Text.ToString();

            cmd.ExecuteNonQuery();

            Kon.Close();

        }

        private void PuniLV()
        {
            listView1.Items.Clear();

            Kon.Open();

            SqlCommand cmd = new SqlCommand("PuniLV", Kon);
            cmd.CommandType = CommandType.StoredProcedure;

            dr = cmd.ExecuteReader();

            while (dr.Read())
            {

                ListViewItem red = new ListViewItem(dr[0].ToString());
                for (int i = 1; i < 7; i++) /* i IDE DO KOLIKO POLJA VRACA PROCEDURA*/
                    red.SubItems.Add(dr[i].ToString());
                listView1.Items.Add(red);
            }
            Kon.Close();


        }

        private void SaLV_NaKontrole()
        {
            foreach (ListViewItem item in listView1.SelectedItems)
            {
                id = Convert.ToInt32(item.SubItems[0].Text);
                
                txtRadnikID.Text = id.ToString();
                txtIme.Text = item.SubItems[1].Text;
                txtPrezime.Text = item.SubItems[2].Text;
                dtDatumR.Text = item.SubItems[3].Text;
                maskedDatumZap.Text = item.SubItems[4].Text;
                txtPlata.Text = item.SubItems[5].Text;
                checkBoxOU.Checked = Convert.ToBoolean(item.SubItems[6].Text);
                
            }

        }
        private void iNSERTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            UnosRadnika();  
            PuniLV();
            PrazniKontrole();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SaLV_NaKontrole();
        }

        private void btnPrazniKontrole_Click(object sender, EventArgs e)
        {
            PrazniKontrole();
        }

        private void uPDATEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            IzmenaRadnika();
            PuniLV();
            PrazniKontrole();
        }

        private void dELETEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string poruka = "Zelite da obrisete radnika?";
            string naslov = "Brisanje radnika";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(poruka, naslov, buttons);

            if (result == DialogResult.Yes)
            {
                BrisiRadnika();
            }

            PuniLV();
            PrazniKontrole();
        }

        private void aNALIZAToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            form2.ShowDialog();
        }
    }
}
